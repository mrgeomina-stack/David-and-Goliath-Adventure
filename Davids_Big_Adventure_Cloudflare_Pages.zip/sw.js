/* Generated local assets only. An update stays waiting until the player accepts it. */
const VERSION = "ece5c43f82d076e2";
const FILES = ["index.html","assets/animals-atlas-CG1G9G9U.png","assets/approach-ar-_cO2dcJG.mp3","assets/approach-en-BGB9KLHQ.mp3","assets/armor-clatter-Bze0yqVq.mp3","assets/armor-fall-B9EpraMu.mp3","assets/armor_fall_00--pX0-zMQ.png","assets/armor_fall_01-zDJRazgo.png","assets/armor_helmet-DEsEMIwh.png","assets/armor_idle-DFburnYm.png","assets/armor_mail-DpOPsiFM.png","assets/armor_recover-Byyw-MqU.png","assets/armor_remove_00-DMBqRllg.png","assets/armor_remove_01-j8bOvwG8.png","assets/armor_remove_02-CgR4fvEL.png","assets/armor_seated-HVTfxcL2.png","assets/armor_step-DkuC0t3K.png","assets/armor_sword-B68zPT_t.png","assets/armor_tunic-CFZP8o3k.png","assets/armor_wobble_00-BEAN5Y-8.png","assets/armor_wobble_01-BZrP-Eev.png","assets/brother_01_receive-CjwFTG4R.png","assets/brother_01_welcome-8Ov6mHY4.png","assets/brother_02_cheer-LgvkJg_y.png","assets/brother_02_idle-C5Hyq44K.png","assets/brother_03_clap-Bltq1WQs.png","assets/brother_03_idle-DS7tAvAi.png","assets/button_blank-DSj4Vif6.png","assets/cast-atlas-CnTjAnfi.png","assets/challenge-ar-56_lCLfs.mp3","assets/challenge-en-ks6bcp3c.mp3","assets/countryside-C1_JJN4s.png","assets/david-determined-rig-DC7h9vbz.png","assets/david-hero-Dx3CmoGV.png","assets/david-rig-Curf3T6a.png","assets/dress_00-BuFbFfl0.png","assets/dress_01--1TN7hGf.png","assets/dress_02-D07_LybA.png","assets/fall_00-DdhgC_wj.png","assets/fall_01-bzDZJNx5.png","assets/fall_02-D8YRNtSq.png","assets/fall_03-DgWkqSkB.png","assets/fence-VjW8WN-L.png","assets/food_basket-C5UaWI8B.png","assets/food_carry-DKm3tmL1.png","assets/food_offer-DxUnrmPE.png","assets/forward-fall-atlas-Dwc9dR3D.png","assets/goliath-actor-CoMfwyGs.png","assets/goliath-challenge-DTdpVJo9.png","assets/goliath-laugh-Bj3Phwlf.mp3","assets/goliath-laugh-CU-MjwqP.png","assets/hit-CmvP8o2X.png","assets/idle-CA0s7lEk.png","assets/idle-DatgSvBV.png","assets/index-BtqxnuTl.css","assets/index-Bv_3JrjE.js","assets/interlude-goliath-ar-DEQNfGgS.mp3","assets/interlude-goliath-en-iDIqI-sE.mp3","assets/interlude-jesse-ar-BVnc-OhK.mp3","assets/interlude-jesse-en-gAz8AekP.mp3","assets/jesse-close-BHuiOaQG.png","assets/jesse-farewell-CE96C1Ux.png","assets/jesse-handover-TT0yAS4p.png","assets/jesse-welcome-12yGUEWw.png","assets/journey-map-1Ii7KeT4.png","assets/kneel_collect_00-DUYMEUBq.png","assets/kneel_collect_01-H-GiHbhC.png","assets/kneel_collect_02-qGLWvLlC.png","assets/level02_maze_ground_1920x1080-CSyyb2uR.png","assets/level03_saul_tent_1920x1080-DdnGZMzs.png","assets/level04_brook_1920x1080-B6WrD6lC.png","assets/level05_battlefield_1920x1080-CF-eYL-u.png","assets/lion-roar-CP7qIRHk.mp3","assets/lion_idle-WUI2-J-h.png","assets/lion_retreat-D470SKi_.png","assets/lion_walk_00-CtZRF3-e.png","assets/lion_walk_01-CT6DSTmu.png","assets/magnific-buttons-and-pins-CzWCpyxh.mp3","assets/maze_wall_shrub-aYwYsASt.png","assets/maze_wall_stone-kphx2CwN.png","assets/meadow-CWl6vboY.png","assets/medal-CyUvmeCL.png","assets/noto-sans-arabic-BhzieyvS.woff2","assets/nunito-latin-BzFMHfZw.woff2","assets/panel_blank-DDBEf43R.png","assets/pen_gate-DAxc_Is7.png","assets/pouch-CBCwb7wl.png","assets/pouch_store-PFFXgt3k.png","assets/props-atlas-DjdnhcGA.png","assets/rig_idle-AHZWBBnl.png","assets/run_00-BA0IEOAs.png","assets/run_01-CQnC93qL.png","assets/run_02-DZbyV0Gs.png","assets/run_03-BqkClRpH.png","assets/saul-Wypkm8WA.png","assets/saul-ar-B7Voa1Ur.mp3","assets/saul-en-BcGJ43NU.mp3","assets/sheep-B5shEq7a.mp3","assets/sheep_hop_00-D4c38ILn.png","assets/sheep_hop_01-YkIdcaux.png","assets/sheep_idle_01-Dbm5CEP-.png","assets/sheep_idle_02-BG4Rggqi.png","assets/sheep_idle_03-BK3nVr4l.png","assets/sheep_walk_00-BZNc1JB8.png","assets/sheep_walk_01-gIuL6gdD.png","assets/sheep_walk_02-DmT0MYip.png","assets/shepherd_call-DcylBon_.png","assets/sling-CqsokwRD.png","assets/sling_charge_00-3I_ZE25C.png","assets/sling_charge_01-I9SGKiE0.png","assets/sling_charge_02-VDVa9BXw.png","assets/sling_charge_03-DB7z-7Nl.png","assets/sling_followthrough-DeNPCHNm.png","assets/sling_release-CyvVmim3.png","assets/soldier-A2NGPPCD.png","assets/staff-gV466r0H.png","assets/stone_01-BXJ6jf6k.png","assets/stone_02-Bmw8DsVk.png","assets/stone_03-CGzaLeMu.png","assets/stone_jagged-DCGWX5V_.png","assets/stumble-COiPmai-.png","assets/success_star-DCy0YriY.png","assets/taunt-Bg8rce4H.png","assets/thankful-B0ykSgB5.png","assets/valley-plate-pIgGN1TU.png","assets/victory-N225R9UH.mp3","assets/walk_00-D3ZhPRYp.png","assets/walk_01-DYC4dE9H.png","assets/walk_02-CBMTS73r.png","assets/walk_03-C-h3B3uz.png","assets/win_00-C0zI1usc.png","assets/win_01-BaanIBiq.png","icons/apple-touch-icon.png","icons/icon-192.png","icons/icon-512.png","icons/maskable-512.png","licenses/EVENTEMITTER3_LICENSE.txt","licenses/NOTO_ARABIC_OFL.txt","licenses/NUNITO_OFL.txt","licenses/PHASER_LICENSE.md","manifest.webmanifest"];
// Isolate copies hosted at different paths on the same origin.
const PREFIX = "davids-pages:" + self.registration.scope + ":";
const CACHE = PREFIX + VERSION;
const REQUIRED = FILES.map(
  (path) => new URL(path, self.registration.scope).href,
);
const PATHS = new Set(REQUIRED.map((url) => new URL(url).pathname));
self.addEventListener("install", (event) => {
  event.waitUntil(
    (async () => {
      try {
        const cache = await caches.open(CACHE);
        // Bound download concurrency and memory on phones. No partial version is activated.
        for (let i = 0; i < REQUIRED.length; i += 6)
          await cache.addAll(
            REQUIRED.slice(i, i + 6).map(
              (url) => new Request(url, { cache: "reload" }),
            ),
          );
      } catch (error) {
        await caches.delete(CACHE);
        throw error;
      }
    })(),
  );
});
self.addEventListener("activate", (event) => {
  event.waitUntil(
    (async () => {
      for (const key of await caches.keys())
        if (key.startsWith(PREFIX) && key !== CACHE) await caches.delete(key);
      await self.clients.claim();
    })(),
  );
});
self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") self.skipWaiting();
  if (event.data?.type === "CACHE_STATUS")
    event.waitUntil(
      (async () => {
        const cache = await caches.open(CACHE);
        const entries = await Promise.all(
          REQUIRED.map((url) => cache.match(url)),
        );
        event.ports[0]?.postMessage({
          ready: entries.every(Boolean),
          version: VERSION,
        });
      })(),
    );
});
self.addEventListener("fetch", (event) => {
  const request = event.request,
    url = new URL(request.url),
    scope = new URL(self.registration.scope);
  if (
    request.method !== "GET" ||
    url.origin !== scope.origin ||
    !url.pathname.startsWith(scope.pathname)
  )
    return;
  if (request.mode === "navigate") {
    // Keep HTML and hashed assets from one release together until an accepted update.
    event.respondWith(
      (async () => {
        const cached = await (await caches.open(CACHE)).match(REQUIRED[0]);
        return cached || fetch(request);
      })(),
    );
  } else if (PATHS.has(url.pathname)) {
    event.respondWith(
      (async () => {
        const cached = await (
          await caches.open(CACHE)
        ).match(request, { ignoreSearch: true });
        return cached || fetch(request);
      })(),
    );
  }
});
